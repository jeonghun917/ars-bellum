from .....services import LogService
from .....services import MaterialService
from .....services import NodeService
from .....services import ObjectService
from .....services import LocationService
from .....services import TargetService
from ..... import ClassManager
from ....mpfboperator import MpfbOperator
from ....pollstrategy import pollstrategy, PollStrategy
import bpy, json, math, os
from bpy.types import StringProperty
from bpy_extras.io_utils import ImportHelper

_LOG = LogService.get_logger("basemeshops.operators.deletehelpers")

@pollstrategy(PollStrategy.BASEMESH_ACTIVE)
class MPFB_OT_Delete_Helpers_Operator(MpfbOperator):
    """Delete all helper geometry. This will also delete the mask operator for hiding helpers. WARNING: You will not be able to equip many clothes after doing this"""
    bl_idname = "mpfb.delete_helpers"
    bl_label = "Delete helpers"
    bl_options = {'REGISTER', 'UNDO'}

    def get_logger(self):
        return _LOG

    def _delete_vertex_group(self, context, blender_object, vgroup_name):
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        bpy.ops.object.select_all(action='DESELECT')
        context.view_layer.objects.active = blender_object
        blender_object.select_set(True)
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)

        group_idx = None
        for group in blender_object.vertex_groups:
            _LOG.dump("group name", group.name)
            if vgroup_name in group.name:
                group_idx = group.index
        _LOG.dump("group index", group_idx)

        for vertex in blender_object.data.vertices:
            vertex.select = False
            for group in vertex.groups:
                if group.group == group_idx:
                    vertex.select = True
            _LOG.dump("Vertex index, selected", (vertex.index, vertex.select))

        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
        bpy.ops.mesh.delete(type='VERT')
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        blender_object.select_set(False)

    def hardened_execute(self, context):
        _LOG.enter()

        obj = context.active_object

        objtype = ObjectService.get_object_type(obj)

        if objtype != "Basemesh":
            self.report({'ERROR'}, "Can only delete helpers on basemesh")
            return {'FINISHED'}

        context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)

        self._delete_vertex_group(context, obj, "HelperGeometry")
        self._delete_vertex_group(context, obj, "JointCubes")

        for modifier in obj.modifiers:
            if modifier.type == 'MASK' and modifier.vertex_group == 'body':
                obj.modifiers.remove(modifier)

        self.report({'INFO'}, "Helper geometry deleted")

        if TargetService.has_any_shapekey(obj):
            TargetService.reapply_all_details(obj)

        obj.select_set(True)
        ObjectService.activate_blender_object(obj)

        return {'FINISHED'}

ClassManager.add_class(MPFB_OT_Delete_Helpers_Operator)
